import React, { useEffect, useState } from 'react';
import { getFlights } from '../../services/flightService';
import { Flight } from '../../models/Flight';

const FlightList: React.FC = () => {
  const [flights, setFlights] = useState([]);

  useEffect(() => {
    fetchFlights();
  }, []);

  const fetchFlights = async () => {
    const response = await getFlights();
    setFlights(response.data);
  };

  return (
    <div>
    <h1>Flights</h1>
    <table>
      <thead>
        <tr>
          <th>Flight ID</th>
          <th>Origin</th>
          <th>Destination</th>
          <th>Departure Time</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {flights.map((flight: Flight) => (
          <tr key={flight.flightId}>
            <td>{flight.flightId}</td>
            <td>{flight.origin}</td>
            <td>{flight.destination}</td>
            <td>{flight.departureTime}</td>
            <td>
              <button onClick={() => { /* Implement delete functionality */ }}>
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
  );
};

export default FlightList;

