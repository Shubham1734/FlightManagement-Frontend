import { useEffect, useState } from "react";
import { useParams } from 'react-router-dom';
import { getFlightById } from "../../services/flightService";
const BookingDetail = () => {
    const [flight, setFlight] = useState([]);
    const {flightId} = useParams<{ flightId: string }>();
    const [ticketQuantity, setTicketQuantity] = useState<number>(1);
    const [totalPrice, setTotalPrice] = useState<number>(flight.price);

    useEffect(() => {
      setTotalPrice(flight.price * ticketQuantity);
    }, [ticketQuantity, flight.price]);

    useEffect(() => {
      fetchFlight();
    }, [flightId]);
    
    const fetchFlight = async () => {
      // const id = parseInt(flightId);
      const response = await getFlightById(flightId);
      setFlight(response.data);
    };

      const handleIncreaseQuantity = () => {
        if (ticketQuantity < flight.capacity - flight.bookedSeats) {
          setTicketQuantity(ticketQuantity + 1);
        }
      };
    
      const handleDecreaseQuantity = () => {
        if (ticketQuantity > 1) {
          setTicketQuantity(ticketQuantity - 1);
        }
      };
  return (
    <div>
      <h1>Booking Page</h1>
      <p>Booking for flight ID: {flightId}</p>
      <h2>Flight Details</h2>
      <p><strong>Origin:</strong> {flight.origin}</p>
      <p><strong>Destination:</strong> {flight.destination}</p>
      <p><strong>Departure Time:</strong> {new Date(flight.departureTime).toLocaleString()}</p>
      <p><strong>Arrival Time:</strong> {new Date(flight.arrivalTime).toLocaleString()}</p>
      <p><strong>Price per Ticket:</strong> ${flight.price}</p>
      <h2>Select Ticket Quantity</h2>
      <div>
        <button onClick={handleDecreaseQuantity}>-</button>
        <span>{ticketQuantity}</span>
        <button onClick={handleIncreaseQuantity}>+</button>
      </div>
      <h2>Total Price: ${totalPrice}</h2>
      <button onClick={() => {}}>Confirm Booking</button>
    </div>
  )
}

export default BookingDetail
