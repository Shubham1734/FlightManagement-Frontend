import React, { useState } from "react";
// import "../../css/addflight.css";
import * as flightService from "../../services/flightService";

const AddFlight = () => {
  const [flight, setFlight] = useState({
    flightId: "",
    origin: "",
    destination: "",
    departureTime: "",
    arrivalTime: "",
    capacity: 0,
    price: 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFlight({ ...flight, [name]: value });
  };

  const handleFlight = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log(flight);
    const response = await flightService.addFlight(flight);
    console.log(response.data);
  };

  return (
    <>
      <h2>Enter New Flight Details</h2>
      <form onSubmit={handleFlight}>
      <div className="add-container">
        <input
          type="text"
          name="flightNumber"
          placeholder="Flight Number"
          value={flight.flightId}
          onChange={handleChange}
        />
        <br />
        <input
          type="text"
          name="origin"
          placeholder="Origin"
          value={flight.origin}
          onChange={handleChange}
        />
        <br />
        <input
          type="text"
          name="destination"
          placeholder="Destination"
          value={flight.destination}
          onChange={handleChange}
        />
        <br />
        <input
          type="datetime-local"
          name="departureTime"
          value={flight.departureTime}
          onChange={handleChange}
        />
        <br />
        <input
          type="datetime-local"
          name="arrivalTime"
          value={flight.arrivalTime}
          onChange={handleChange}
        />
        <br />
        <input
          type="number"
          name="capacity"
          placeholder="Capacity"
          value={flight.capacity}
          onChange={handleChange}
        />
        <br />
        <input
          type="number"
          name="price"
          placeholder="price"
          value={flight.price}
          onChange={handleChange}
        />
        <br />
        <button>Add Flight</button>
      </div>
      </form>
    </>
  );
};

export default AddFlight;
