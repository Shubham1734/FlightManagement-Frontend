import axios from 'axios';
const API_URL = 'http://localhost:8080/api/users';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const registerUser = (user: any) => {
    return axios.post(`${API_URL}`, user);
};

export const getUser = (email : string , password : string)=>{
    return axios.get(`${API_URL}`+ "/search",{params: {email,password}})
}