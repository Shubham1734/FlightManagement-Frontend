import axios from 'axios';
const API_URL = 'http://localhost:8080/api/flights';
export const getFlights = () => {
    console.log(axios.get(API_URL));
    return axios.get(API_URL);
}

export const getFlightByorigindest = (origin: string,destination: string) =>{
    console.log(axios.get(API_URL))
    return axios.get(API_URL+"/search",{
        params: {origin,destination}
    });
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const addFlight = (flight : any) =>{
    return axios.post(API_URL,flight);
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const updateFlight = (id:number,flight:any) =>{
    // console.log(axios.put(API_URL+"/"+flight.flightId,flight))
    return axios.put(`${API_URL}/${id}`,flight);
}

export const getFlightById = (flightId:string) => {
    const url = `${API_URL}/${flightId}`;
    console.log(axios.get(url));
    return axios.get(url);
};