import { FormEvent, useState } from 'react'
import {getFlightByorigindest} from '../../services/flightService';
import { Flight } from '../../models/Flight';
import { Link, useNavigate } from 'react-router-dom';
import '../../styles/FlightSearch.css'
const FlightSearch = () => {
    const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
//   eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [flights, setFlights] = useState<Flight[]>([]);
  const navigate = useNavigate();
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async function handleSubmit(event: FormEvent<HTMLFormElement>): Promise<void> {
        event.preventDefault();
        const response = await getFlightByorigindest(origin,destination);
        console.log(typeof(response.data));
        console.log(response.data)
        setFlights(response.data);
    }

  const handleBook = (flightId :  number) => {
    navigate(`/book/${flightId}`);
  }

  return (
    <>

      <nav>
        <ul>
          <li><Link to="/login">Login</Link></li>
          <li><Link to="/register">Register</Link></li>
          <li><Link to="/user-profile">User Profile</Link></li>
        </ul>
      </nav>
    <form onSubmit={(handleSubmit)}>
      <input
        type="text"
        placeholder="Origin"
        value={origin}
        onChange={(e) => setOrigin(e.target.value)}
        required
        />
      <input
        type="text"
        placeholder="Destination"
        value={destination}
        onChange={(e) => setDestination(e.target.value)}
        required
      />
      <button type="submit">Search Flights</button>
    </form>
    {flights.length > 0 && (
        <div>
          <h2>Search Results</h2>
          <table>
            <thead>
              <tr>
                <th>Flight ID</th>
                <th>Origin</th>
                <th>Destination</th>
                <th>Departure Time</th>
                <th>Arrival Time</th>
                <th>Price</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {flights.map((flight) => (
                <tr key={flight.flightId}>
                  <td>{flight.flightId}</td>
                  <td>{flight.origin}</td>
                  <td>{flight.destination}</td>
                  <td>{flight.departureTime}</td>
                  <td>{flight.arrivalTime}</td>
                  <td>{flight.price}</td>
                  <button onClick={() => handleBook(flight.flightId)}>Book</button>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
            </>
    )
}

export default FlightSearch
// San Francisco	Chicago