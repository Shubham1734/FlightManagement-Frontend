import React, { useState } from 'react'
import { getUser } from '../../services/userService';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addUser } from '../../Redux/actions/userAction';

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [flag, setFlag] = useState(false);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try{
      const response = await getUser(email,password);
      console.log(response.data)
      dispatch(addUser(response.data));
      console.log(typeof(response));
      // handleaddUser(response);
      navigate('/flights-search')
      
    }
    catch(e){
      setFlag(true)
      console.log("something wrong");
    }
    // console.log('Email:', email);
    // console.log('Password:', password);

  };
  return (
    <>
    <div style={{ maxWidth: '400px', margin: 'auto', padding: '20px' }}>
    <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email:</label>
          <input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required 
          />
        </div>
        <div>
          <label>Password:</label>
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
        </div>
        <div>
          <button type="submit">Login</button>
        </div>
        <div>
        {flag === true ? <><h4>Invalid credentials</h4></> : <></>}
        </div>
      </form>
    </div>
    </>
  )
}

export default Login


